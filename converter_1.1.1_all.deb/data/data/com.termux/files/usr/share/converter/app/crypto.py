#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
import hashlib
import base64
import socket

class CryptoManager:
    """Gestiona el cifrado y descifrado de datos sensibles original."""
    def __init__(self):
        self.salt = b'converter_milux_dnp_2024'
        self.key = self._generate_key()

    def _get_unique_id(self):
        try:
            id_path = os.path.expanduser("~/.gemini/installation_id")
            if os.path.exists(id_path):
                with open(id_path, 'r') as f: return f.read().strip()
            return socket.gethostname()
        except: return "default_converter_host"

    def _generate_key(self):
        unique_id = self._get_unique_id().encode('utf-8')
        return hashlib.sha256(self.salt + unique_id).digest()

    def encrypt(self, plaintext):
        if not plaintext: return None
        if isinstance(plaintext, str): plaintext = plaintext.encode('utf-8')
        encrypted = bytearray()
        for i in range(len(plaintext)):
            encrypted.append(plaintext[i] ^ self.key[i % len(self.key)])
        return base64.b64encode(encrypted).decode('utf-8')

    def decrypt(self, ciphertext):
        if not ciphertext: return None
        try:
            encrypted_bytes = base64.b64decode(ciphertext)
            decrypted = bytearray()
            for i in range(len(encrypted_bytes)):
                decrypted.append(encrypted_bytes[i] ^ self.key[i % len(self.key)])
            return decrypted.decode('utf-8')
        except: return ciphertext
